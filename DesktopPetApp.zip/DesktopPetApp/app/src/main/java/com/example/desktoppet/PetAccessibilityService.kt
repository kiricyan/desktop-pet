package com.example.desktoppet

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * 无障碍服务：安卓不允许App随意"截取"其他App的内容，
 * 唯一合法且不需要不断弹通知的方式就是通过无障碍服务读取界面结构。
 * 用户需要手动去 系统设置 -> 无障碍 -> 找到"桌宠" -> 开启。
 */
class PetAccessibilityService : AccessibilityService() {

    companion object {
        // 供OverlayService读取的最新状态，简单起见用静态变量
        @Volatile var currentPackageName: String = ""
            private set

        @Volatile var currentScreenText: String = ""
            private set
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val pkg = event.packageName?.toString() ?: return
        currentPackageName = pkg

        // 读取当前界面可见的文字内容(限制长度，避免太大也没意义)
        val root: AccessibilityNodeInfo = rootInActiveWindow ?: return
        val sb = StringBuilder()
        collectText(root, sb, 0)
        currentScreenText = sb.toString().take(500)
    }

    private fun collectText(node: AccessibilityNodeInfo?, sb: StringBuilder, depth: Int) {
        if (node == null || depth > 12 || sb.length > 500) return
        node.text?.let {
            if (it.isNotBlank()) sb.append(it).append("。")
        }
        for (i in 0 until node.childCount) {
            collectText(node.getChild(i), sb, depth + 1)
        }
    }

    override fun onInterrupt() {}
}
