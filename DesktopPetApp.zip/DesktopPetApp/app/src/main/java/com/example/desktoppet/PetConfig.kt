package com.example.desktoppet

import android.content.Context

/**
 * 桌宠的所有配置，用SharedPreferences持久化保存。
 * 用户在MainActivity里填写，OverlayService读取使用。
 */
object PetConfig {

    private const val PREF_NAME = "pet_config"

    private const val KEY_API_BASE_URL = "api_base_url"
    private const val KEY_API_KEY = "api_key"
    private const val KEY_MODEL = "model"
    private const val KEY_PERSONA = "persona"
    private const val KEY_WALK_ENABLED = "walk_enabled"
    private const val KEY_ROAST_INTERVAL_MIN = "roast_interval_min"
    private const val KEY_PET_NAME = "pet_name"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    // 默认使用OpenAI兼容格式，方便接入中转站/Gemini/Claude的兼容代理
    var apiBaseUrl: String
        get() = _cachedContext?.let { prefs(it).getString(KEY_API_BASE_URL, "https://api.openai.com/v1/chat/completions") ?: "" } ?: ""
        set(value) { _cachedContext?.let { prefs(it).edit().putString(KEY_API_BASE_URL, value).apply() } }

    var apiKey: String
        get() = _cachedContext?.let { prefs(it).getString(KEY_API_KEY, "") ?: "" } ?: ""
        set(value) { _cachedContext?.let { prefs(it).edit().putString(KEY_API_KEY, value).apply() } }

    var model: String
        get() = _cachedContext?.let { prefs(it).getString(KEY_MODEL, "gpt-4o-mini") ?: "" } ?: ""
        set(value) { _cachedContext?.let { prefs(it).edit().putString(KEY_MODEL, value).apply() } }

    var persona: String
        get() = _cachedContext?.let {
            prefs(it).getString(
                KEY_PERSONA,
                "你是一只毒舌但可爱的桌面宠物，喜欢用简短犀利又不失幽默的话吐槽主人正在做的事情，每次回复不超过40字。"
            ) ?: ""
        } ?: ""
        set(value) { _cachedContext?.let { prefs(it).edit().putString(KEY_PERSONA, value).apply() } }

    var petName: String
        get() = _cachedContext?.let { prefs(it).getString(KEY_PET_NAME, "小宠") ?: "" } ?: ""
        set(value) { _cachedContext?.let { prefs(it).edit().putString(KEY_PET_NAME, value).apply() } }

    var walkEnabled: Boolean
        get() = _cachedContext?.let { prefs(it).getBoolean(KEY_WALK_ENABLED, true) } ?: true
        set(value) { _cachedContext?.let { prefs(it).edit().putBoolean(KEY_WALK_ENABLED, value).apply() } }

    var roastIntervalMinutes: Int
        get() = _cachedContext?.let { prefs(it).getInt(KEY_ROAST_INTERVAL_MIN, 3) } ?: 3
        set(value) { _cachedContext?.let { prefs(it).edit().putInt(KEY_ROAST_INTERVAL_MIN, value).apply() } }

    // 简单的上下文缓存，实际使用时在Application/Service里调用init()设置一次即可
    private var _cachedContext: Context? = null
    fun init(context: Context) {
        _cachedContext = context.applicationContext
    }
}
