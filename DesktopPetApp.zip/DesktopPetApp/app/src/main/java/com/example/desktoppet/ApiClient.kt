package com.example.desktoppet

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * 简单的OpenAI兼容格式(Chat Completions)客户端。
 * 大部分第三方中转站、以及不少Gemini/Claude的代理网关都支持这个格式，
 * 所以只需要让用户填 base_url + api_key + model 即可通用接入。
 */
object ApiClient {

    /**
     * @param systemPrompt 人设/性格设定
     * @param userMessage 具体想让AI回应的内容(比如"主人正在用微信聊天，请吐槽")
     * @return AI返回的文字，失败时返回null
     */
    suspend fun chat(systemPrompt: String, userMessage: String): String? = withContext(Dispatchers.IO) {
        try {
            val url = URL(PetConfig.apiBaseUrl)
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Authorization", "Bearer ${PetConfig.apiKey}")
            conn.doOutput = true
            conn.connectTimeout = 15000
            conn.readTimeout = 20000

            val messages = JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "system")
                    put("content", systemPrompt)
                })
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", userMessage)
                })
            }

            val body = JSONObject().apply {
                put("model", PetConfig.model)
                put("messages", messages)
                put("max_tokens", 150)
                put("temperature", 0.9)
            }

            OutputStreamWriter(conn.outputStream).use { it.write(body.toString()) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val response = BufferedReader(InputStreamReader(stream)).use { it.readText() }

            if (code !in 200..299) {
                return@withContext "（API出错 $code：${response.take(80)}）"
            }

            val json = JSONObject(response)
            val choices = json.optJSONArray("choices") ?: return@withContext null
            if (choices.length() == 0) return@withContext null
            val message = choices.getJSONObject(0).optJSONObject("message")
            message?.optString("content")?.trim()
        } catch (e: Exception) {
            "（网络出错：${e.message?.take(60)}）"
        }
    }
}
