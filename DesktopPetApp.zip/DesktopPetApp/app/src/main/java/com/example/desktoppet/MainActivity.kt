package com.example.desktoppet

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {

    private lateinit var etBaseUrl: EditText
    private lateinit var etApiKey: EditText
    private lateinit var etModel: EditText
    private lateinit var etPetName: EditText
    private lateinit var etPersona: EditText
    private lateinit var etRoastInterval: EditText
    private lateinit var switchWalk: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        PetConfig.init(applicationContext)

        etBaseUrl = findViewById(R.id.etBaseUrl)
        etApiKey = findViewById(R.id.etApiKey)
        etModel = findViewById(R.id.etModel)
        etPetName = findViewById(R.id.etPetName)
        etPersona = findViewById(R.id.etPersona)
        etRoastInterval = findViewById(R.id.etRoastInterval)
        switchWalk = findViewById(R.id.switchWalk)

        loadCurrentConfig()

        findViewById<Button>(R.id.btnGrantOverlay).setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }

        findViewById<Button>(R.id.btnGrantAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "请在列表中找到「桌宠」并开启", Toast.LENGTH_LONG).show()
        }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            saveConfig()
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "请先开启悬浮窗权限", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ActivityCompat.requestPermissions(
                    this, arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 100
                )
            }
            startForegroundService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "桌宠已启动，切到桌面或其他App就能看到啦", Toast.LENGTH_LONG).show()
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "桌宠已停止", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadCurrentConfig() {
        etBaseUrl.setText(PetConfig.apiBaseUrl)
        etApiKey.setText(PetConfig.apiKey)
        etModel.setText(PetConfig.model)
        etPetName.setText(PetConfig.petName)
        etPersona.setText(PetConfig.persona)
        etRoastInterval.setText(PetConfig.roastIntervalMinutes.toString())
        switchWalk.isChecked = PetConfig.walkEnabled
    }

    private fun saveConfig() {
        PetConfig.apiBaseUrl = etBaseUrl.text.toString().trim()
        PetConfig.apiKey = etApiKey.text.toString().trim()
        PetConfig.model = etModel.text.toString().trim()
        PetConfig.petName = etPetName.text.toString().trim().ifBlank { "小宠" }
        PetConfig.persona = etPersona.text.toString().trim()
        PetConfig.roastIntervalMinutes = etRoastInterval.text.toString().toIntOrNull() ?: 3
        PetConfig.walkEnabled = switchWalk.isChecked
    }
}
