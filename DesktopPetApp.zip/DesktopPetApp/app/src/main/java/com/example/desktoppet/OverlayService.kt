package com.example.desktoppet

import android.animation.ValueAnimator
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.random.Random

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: View
    private lateinit var params: WindowManager.LayoutParams

    private lateinit var petImage: ImageView
    private lateinit var bubbleText: TextView
    private lateinit var menuRow: LinearLayout

    private val mainHandler = Handler(Looper.getMainLooper())
    private val serviceScope = CoroutineScope(Dispatchers.Main)

    private var walkRunnable: Runnable? = null
    private var roastRunnable: Runnable? = null

    // 用于区分"点击"和"拖动"
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var isDragging = false

    override fun onCreate() {
        super.onCreate()
        PetConfig.init(applicationContext)
        startForegroundServiceNotification()
        setupOverlayView()
        startRoastLoop()
        if (PetConfig.walkEnabled) startWalking()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ---------- 前台服务通知 ----------
    private fun startForegroundServiceNotification() {
        val channelId = "pet_overlay_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "桌宠运行中",
                NotificationManager.IMPORTANCE_MIN
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("${PetConfig.petName} 正在陪伴你")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
        startForeground(1, notification)
    }

    // ---------- 悬浮窗搭建 ----------
    private fun setupOverlayView() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_pet, null)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 100
        params.y = 300

        windowManager.addView(overlayView, params)

        petImage = overlayView.findViewById(R.id.petImage)
        bubbleText = overlayView.findViewById(R.id.bubbleText)
        menuRow = overlayView.findViewById(R.id.menuRow)

        setupTouchListener()
        setupMenuButtons()
    }

    // ---------- 拖动 + 点击弹出菜单 ----------
    private fun setupTouchListener() {
        petImage.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (kotlin.math.abs(dx) > 15 || kotlin.math.abs(dy) > 15) {
                        isDragging = true
                    }
                    if (isDragging) {
                        params.x = initialX + dx
                        params.y = initialY + dy
                        windowManager.updateViewLayout(overlayView, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        toggleMenu()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun toggleMenu() {
        menuRow.visibility = if (menuRow.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    // ---------- 互动按钮 ----------
    private fun setupMenuButtons() {
        overlayView.findViewById<View>(R.id.btnFeed).setOnClickListener {
            interact("喂食", "主人刚喂了你东西吃，请撒娇或吐槽一下。")
        }
        overlayView.findViewById<View>(R.id.btnBathe).setOnClickListener {
            interact("洗澡", "主人正在帮你洗澡，请表达你的感受(可以是抗拒或享受)。")
        }
        overlayView.findViewById<View>(R.id.btnChat).setOnClickListener {
            interact("聊天", "主人想找你聊聊天，随便说点什么。")
        }
        overlayView.findViewById<View>(R.id.btnClose).setOnClickListener {
            menuRow.visibility = View.GONE
        }
    }

    private fun interact(action: String, prompt: String) {
        menuRow.visibility = View.GONE
        val imageRes = when (action) {
            "喂食" -> R.drawable.pet_eating
            "洗澡" -> R.drawable.pet_bathing
            else -> R.drawable.pet_talking
        }
        petImage.setImageResource(imageRes)
        showBubble("...")

        serviceScope.launch {
            val reply = ApiClient.chat(PetConfig.persona, prompt) ?: "（没连上API，检查一下设置）"
            showBubble(reply)
            mainHandler.postDelayed({
                petImage.setImageResource(R.drawable.pet_idle)
            }, 4000)
        }
    }

    // ---------- 定时吐槽 ----------
    private fun startRoastLoop() {
        roastRunnable = object : Runnable {
            override fun run() {
                doRoast()
                val intervalMs = (PetConfig.roastIntervalMinutes.coerceAtLeast(1)) * 60_000L
                mainHandler.postDelayed(this, intervalMs)
            }
        }
        // 第一次延迟30秒再开始，给用户一点缓冲时间
        mainHandler.postDelayed(roastRunnable!!, 30_000L)
    }

    private fun doRoast() {
        val pkg = PetAccessibilityService.currentPackageName
        val screenText = PetAccessibilityService.currentScreenText
        if (pkg.isBlank()) return // 无障碍服务还没启用/没有数据

        val prompt = "主人现在正在使用App：$pkg。屏幕上的部分内容是：$screenText。请用一句话吐槽或调侃主人现在的行为。"
        petImage.setImageResource(R.drawable.pet_talking)
        serviceScope.launch {
            val reply = ApiClient.chat(PetConfig.persona, prompt)
            if (reply != null) {
                showBubble(reply)
            }
            mainHandler.postDelayed({
                petImage.setImageResource(R.drawable.pet_idle)
            }, 4000)
        }
    }

    private var hideBubbleRunnable: Runnable? = null

    private fun showBubble(text: String) {
        bubbleText.text = text
        bubbleText.visibility = View.VISIBLE
        hideBubbleRunnable?.let { mainHandler.removeCallbacks(it) }
        hideBubbleRunnable = Runnable { bubbleText.visibility = View.GONE }
        mainHandler.postDelayed(hideBubbleRunnable!!, 8000L)
    }

    // ---------- 随机走动 ----------
    fun startWalking() {
        if (walkRunnable != null) return
        walkRunnable = object : Runnable {
            override fun run() {
                if (!PetConfig.walkEnabled) return
                val displayMetrics = resources.displayMetrics
                val targetX = Random.nextInt(0, (displayMetrics.widthPixels - 90).coerceAtLeast(1))
                animateTo(targetX)
                mainHandler.postDelayed(this, Random.nextLong(4000, 9000))
            }
        }
        mainHandler.post(walkRunnable!!)
    }

    private fun animateTo(targetX: Int) {
        val animator = ValueAnimator.ofInt(params.x, targetX)
        animator.duration = 1500
        animator.addUpdateListener {
            params.x = it.animatedValue as Int
            try {
                windowManager.updateViewLayout(overlayView, params)
            } catch (_: Exception) {
            }
        }
        animator.start()
    }

    fun stopWalking() {
        walkRunnable?.let { mainHandler.removeCallbacks(it) }
        walkRunnable = null
    }

    override fun onDestroy() {
        super.onDestroy()
        roastRunnable?.let { mainHandler.removeCallbacks(it) }
        stopWalking()
        if (::overlayView.isInitialized) {
            try {
                windowManager.removeView(overlayView)
            } catch (_: Exception) {
            }
        }
    }
}
